﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace img_pro
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            btngrey.Hide();
        }
        

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofile = new OpenFileDialog();
            ofile.Filter = "All files (*.*)|*.*";
            if (DialogResult.OK == ofile.ShowDialog())
            {
                this.picorg.Image = new Bitmap(ofile.FileName);

            }
            btngrey.Show();
        }

        private void btngrey_Click(object sender, EventArgs e)
        {
            Bitmap copy = new Bitmap((Bitmap)this.picorg.Image);
            process.ConvertToGray(copy);
            this.picgrey.Image = copy;
        }
    }
}
