﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace img_pro
{
    public partial class Form2 : Form
    {
        SaveFileDialog sDlg;
        public Form2()
        {
            InitializeComponent();
            btngrey.Hide();
        }
        

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofile = new OpenFileDialog();
            ofile.Filter = "All files (*.*)|*.*";
            if (DialogResult.OK == ofile.ShowDialog())
            {
                this.picorg.Image = new Bitmap(ofile.FileName);

            }
            btngrey.Show();
        }

        private void btngrey_Click(object sender, EventArgs e)
        {
            Bitmap copy = new Bitmap((Bitmap)this.picorg.Image);
            process.ConvertToGray(copy);
            this.picres.Image = copy;
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            picres.Image.Save(path +"\\Processed_Img"+DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + ".jpg");
            MessageBox.Show("Saved successfully...");
            this.Controls.Clear();
            this.InitializeComponent();
        }

        
    }
}
